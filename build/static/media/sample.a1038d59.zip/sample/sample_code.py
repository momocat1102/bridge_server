from AIGamePlatform import Othello
from othello.bots.Random import BOT


app=Othello() # 會開啟瀏覽器登入Google Account，目前只接受@mail1.ncnu.edu.tw及@mail.ncnu.edu.tw
bot=BOT()

@app.competition(competition_id='[competition ID]')
def _callback_(board, color): # 函數名稱可以自訂，board是當前盤面，color代表黑子或白子
    return bot.getAction(board, color) # 回傳要落子的座標

